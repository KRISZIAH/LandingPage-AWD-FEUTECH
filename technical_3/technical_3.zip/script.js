function doMath(wew){

    var result = wew;
    document.form1.answer.value += result;
    }
    
    function equal (){
    
       form1.answer.value = eval(form1.answer.value);
    }
    
    function clear1 (wewes){
        var output = document.getElementById("display").value = "";
    }